const SHEET_NAME = "Голоса";

function doGet() {
  return HtmlService.createHtmlOutputFromFile("Index")
    .setTitle("Выборы в Госдуму Санкт-Петербурга | Minecraft RP")
    .addMetaTag("viewport", "width=device-width, initial-scale=1");
}

function submitVote(party) {
  const allowed = ["Единая Сила Петербурга", "Независимый Петербург"];
  if (!allowed.includes(party)) {
    throw new Error("Некорректный вариант голосования.");
  }

  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    let sheet = ss.getSheetByName(SHEET_NAME);
    if (!sheet) {
      sheet = ss.insertSheet(SHEET_NAME);
      sheet.appendRow(["Время", "Партия"]);
    }
    sheet.appendRow([new Date(), party]);
    return { ok: true, message: "Ваш голос учтён. Спасибо за участие!" };
  } finally {
    lock.releaseLock();
  }
}

function getResults() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sheet = ss.getSheetByName(SHEET_NAME);
  const counts = {
    "Единая Сила Петербурга": 0,
    "Независимый Петербург": 0
  };
  if (sheet && sheet.getLastRow() > 1) {
    const values = sheet.getRange(2, 2, sheet.getLastRow() - 1, 1).getValues();
    values.forEach(row => {
      if (Object.prototype.hasOwnProperty.call(counts, row[0])) counts[row[0]]++;
    });
  }
  const total = counts["Единая Сила Петербурга"] + counts["Независимый Петербург"];
  return {
    total,
    parties: Object.keys(counts).map(name => ({
      name,
      votes: counts[name],
      percent: total ? Math.round(counts[name] / total * 100) : 0
    }))
  };
}
